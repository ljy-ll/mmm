<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="../share/CSS.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<style type="text/css">
#form{
	margin:auto;
	text-align:center;
	}
</style>
</head>

<body>
<table class="d">
<td>
<a href="Course.php" class="p">浏览课程</a>
</td>
<td>
<a href="TeacherQuery.php" class="p">查询课程</a>
</td>
<td>
<a href="AddCourse.php" class="p">添加课程</a>
</td>
<td>
<a href="../Login.html" class="p">退出系统</a>
</td>
</table>
<div id="form">
<form enctype="multipart/form-data" action="" method="post">
<select name="XuanZe" style="border:#CCC solid 2px;">
<option value="课程编号" selected>课程编号</option>
<option value="关键字" selected>关键字</option>
</select>
<input type="text" name="search" style="border:#CCC solid 2px;"/>
<input type="submit" name="query" value="查询"/>
</form>
</div>
<?php
include '../share/GongYong.php';
$conn = get_Connect();
if(isset($_POST["query"])) {
$search = $_POST['search'];
	if($search!=null){
		if($_POST['XuanZe']=="关键字"){
$sql = "select CouNo,CouName,kind,Credit,Teacher,SchoolTime,LimitNum from course where CouName like '%{$search}%'";
		}else{
			$sql = "select CouNo,CouName,kind,Credit,Teacher,SchoolTime,LimitNum from course where CouNo like '%{$search}%'";
		}
@$result = mysql_query($sql);
@$total_records=mysql_num_rows($result);//查询总有多少条数据
if($total_records>0){
echo "<table cellspacing='3' cellpadding='5' class='table'>";
echo "<tr class='tr'>"."<th>"."课程编号"."</th>"."<th>"."课程名称"."</th>"."<th>"."课程类别"."</th>"."<th>"."学分"."</th>"."<th>"."任课老师"."</th>"."<th>"."上课时间"."</th>"."<th>"."限制人数"."</th>"."<th>"."课程操作"."</th>"."</tr>";
while($res=mysql_fetch_array($result)){
echo "<tr class='tr'>";
$b=$res['CouNo'];
echo "<td class='td'>".$res["CouNo"]."</td>";
echo "<td class='td'>".$res["CouName"]."</td>";
echo "<td class='td'>".$res["kind"]."</td>";
echo "<td class='td'>".$res["Credit"]."</td>";
echo "<td class='td'>".$res["Teacher"]."</td>";
echo "<td class='td'>".$res["SchoolTime"]."</td>"; 
echo "<td class='td'>".$res["LimitNum"]."</td>";
echo "<td class='td'>"."<a href=updateCour.php?course=$b>修改</a>"."&nbsp;&nbsp;"."<a href=deleteCour.php?deletecour=$b onclick=\"return confirm('你确定要删除该门课程吗？？')\">删除</a>"."</td>";
echo "</tr>";
}
echo "</table>";
}
if($total_records>0){
echo "<p>鼠标点击修改或删除，可以进行课程相关的操作</p>";
}
if($total_records==0){
 echo '<script language="JavaScript">;alert("抱歉搜索不到内容，看看输入的关键字或编号是否合适？？");location.href="TeacherQuery.php"</script>;';
}
if($total_records>=12){
$page_size=4;//一页显示几条数据
if(isset($_GET["page_current"])) //获取DaoHang页面的超链接的page_current变量。
{
	$page_current=$_GET["page_current"];
}else{
	$page_current=1;//显示第一页
}
$start=($page_current-1)*$page_size;//由计算得出的公式
$url="QueryCour.php";//显示当前的页面名称
include '../share/DaoHang.php';
page($total_records,$page_size,$page_current,$url);
}
	}else{
		echo '<script language="JavaScript">;alert("亲，要输入关键字哟！");location.href="TeacherQuery.php"</script>;';
	}
}
?>
</body>
</html>