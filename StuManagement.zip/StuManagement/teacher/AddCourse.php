<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<style type="text/css">
body { 
	background:#f0e6dc;
}
#content{
	width:390px;
	height:295px;
	margin:auto;
	border:#F99 solid 2px;
	background-color:#f6c5b4;
	}
#top{
	width:390px;
	height:30px;
	line-height:30px;
	text-align:center;
	font-size:24px;
	background-color:#F36;
	color:#333;
	}
#right{
	width:260px;
	height:295px;
	float:right;
	}
#left{
	width:130px;
	height:220px;
	float:left;
	background-color:#0F9;
	}

/*这是第二个表格样式*/	
table{
	background-color:#C66;
	margin:auto;
	border-collapse:collapse;/*让表格的间隙消失*/
			/*caption-side:bottom;这是设置标题的位置*/
}
tr{
	background-color:#f6c5b4;
	font-size:12px;
}
td{
	color:#74534a;
	border:#931966 solid 1px;
}
.th{
	background-color:#f0a36d;
	font-size:12px;
	color:#333;
	border:#931966 solid 1px;
}
.p{
	position:relative;
	right:100px;
	float:right;
	}
td input{
	height:17px;
}
</style>
</head>

<body>
<div id="content">
<div id="top">添加课程</div>
<?php
include '../share/GongYong.php';
$conn = get_Connect();
$sql = "select max(CouNo) as CouNo from course";
$result = mysql_query($sql);
$res=mysql_fetch_array($result);
if($res['CouNo']+1<10){
$couNo=$res['CouNo']+1;
$kecourNo="00".$couNo;
}else{
$couNo=$res['CouNo']+1;
$kecourNo="0".$couNo;
}
echo '<div id="left">';
echo "<form enctype='multipart/form-data' action='' method='post'>
<img src='../uploadpics/$kecourNo.jpg'  width='130' height='220' />
<input type='hidden' name='max_file_size' value='10240000000' />
<input type='file' name='userfile' size='15' style='background:#FFF;' maxlength='100' />
<input type='submit' name='photo' value='上传图片'/>
</form>";
if(isset($_POST["photo"])){
//获取文件类型的文本框放入数组
$file = $_FILES['userfile'];
//获取数组内的值
$name = $file['name'];
$tmp_name = $file['tmp_name'];
//上传文件后转移
	move_uploaded_file($tmp_name,'C:/wamp/www/uploadpics/'.$name);
}
echo '</div>';
echo "<div id='right'>";
$sql3="select distinct Kind from course";
$result3 = mysql_query($sql3);
$stkind="";
while($res3=mysql_fetch_array($result3))
{
	$stkind.="<option>$res3[Kind]</option>";
	}
$sql4="select DepartName from department";
$result4 = mysql_query($sql4);
$stdepartN="";
while($res4=mysql_fetch_array($result4))
{  
		$stdepartN.="<option>$res4[DepartName]</option>";
	}
echo "<form enctype='multipart/form-data' action='' method='post'>";
echo "<table width='260' height='220' class='table'>";
			$str="";
			$str.="<tr>
                            <td class='th'>课程编号</td>
                            <td>$kecourNo</td>
                        </tr>
                        <tr>
                            <td class='th'>课程名称</td>
                            <td><input type='text' name='couName' size='27' maxlength='20' value=''/></td>
                        </tr>
                        <tr>
                            <td class='th'>类型</td>
                            <td>
						<select name='XuanZeK' style='border:#CCC solid 2px;'>
						".$stkind."
						</select>
						</td>
                        </tr>
                        <tr>
                            <td class='th'>学分</td>
                            <td><input type='text' name='credit' size='27' maxlength='2' value=''/></td>
                        </tr>
                        <tr>
                            <td class='th'>教师</td>
                            <td><input type='text' name='teacher' size='27' maxlength='8' value='' /></td>
                        </tr>
                        <tr>
                            <td class='th'>上课时间</td>
                            <td><input type='text' name='time' size='27' maxlength='20' value=''/></td>
                        </tr>
						<tr>
                            <td class='th'>开发系部</td>
                            <td>
						<select name='XuanZeD' style='border:#CCC solid 2px;'>
						".$stdepartN."
						</select>
							</td>
                        </tr>
                        <tr>
                            <td class='th'>限定人数</td>
                            <td><input type='text' name='limit' size='27' maxlength='3' value='' /></td>
                        </tr>
                        </tr>";	
echo $str;
echo "</table>"."<br/>";
echo "<input type='submit' value='添加' style='float:right' name='update' class='p'/>";	
echo "</form>";
echo "<form action='Course.php' method='post'><input type='submit' value='返回' style='float:right'/></form>";
echo "</div>";
if(isset($_POST["update"])){
	$a=$_POST['couName'];
	$b=$_POST['XuanZeK'];
	$c=$_POST['credit'];
	$d=$_POST['teacher'];
	$e=$_POST['time'];
	$f=$_POST['XuanZeD'];
	$g=$_POST['limit'];
	$sql5="select DepartNo from department where DepartName='$f'";
	$result5 = mysql_query($sql5);
	$res5=mysql_fetch_array($result5);
	$sql2 = "insert into course (CouNo,CouName,Kind,Credit,Teacher,DepartNo,SchoolTime,LimitNum) values ('$kecourNo','$a','$b','$c','$d','$res5[DepartNo]','$e','$g')";
$result = mysql_query($sql2);
echo '<script language="JavaScript">alert("添加成功！");location.href="Course.php"</script>';
}
?>
</div>
</body>
</html>