<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="../share/CSS.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table class="d">
<td>
<a href="SelectCour.php" class="p">浏览课程</a>
</td>
<td>
<a href="QueryCour.php" class="p">查询课程</a>
</td>
<td>
<a href="myCour.php" class="p">所选课程</a>
</td>
<td>
<a href="../Login.html" class="p">退出系统</a>
</td>
</table>
<?php
session_start();
$username=$_SESSION['user_name'];
include '../share/GongYong.php';
$conn = get_Connect();
$page_size=3;//一页显示几条数据
if(isset($_GET["page_current"])) //获取DaoHang页面的超链接的page_current变量。
{
	$page_current=$_GET["page_current"];
}else{
	$page_current=1;//显示第一页
}
$start=($page_current-1)*$page_size;//由计算得出的公式
	$sql = "select CouNo,CouName,kind,Credit,Teacher,SchoolTime from course where CouNo not in(select CouNo from stucou where StuNo='$username') limit $start,$page_size";
$result = mysql_query($sql);
/*if($result){
echo "<p>查询course表数据成功!</p>";
}else {
echo "<p>查询course表数据失败！</p>";
}*/
echo "<table cellspacing='3' cellpadding='5' class='table'>";
echo "<tr class='tr'>"."<th>"."课程编号"."</th>"."<th>"."课程名称"."</th>"."<th>"."课程类别"."</th>"."<th>"."学分"."</th>"."<th>"."任课老师"."</th>"."<th>"."上课时间"."</th>"."</tr>";
while($res=mysql_fetch_array($result)){
echo "<tr class='tr'>";
$b=$res['CouNo'];
echo "<td class='td'>"."<a href=MessageCour.php?couNo=$b>".$res["CouNo"]."<a>"."</td>";
echo "<td class='td'>".$res["CouName"]."</td>";
echo "<td class='td'>".$res["kind"]."</td>";
echo "<td class='td'>".$res["Credit"]."</td>";
echo "<td class='td'>".$res["Teacher"]."</td>";
echo "<td class='td'>".$res["SchoolTime"]."</td>";
echo "</tr>";
}
echo "</table>";
echo "<p>鼠标点击课程编号，可以查看课程细节！</p>";
$total_rows=mysql_query("select CouNo,CouName,kind,Credit,Teacher,SchoolTime from course where  CouNo not in(select CouNo from stucou where StuNo='$username')");
$total_records=mysql_num_rows($total_rows);//查询总有多少条数据
$url=$_SERVER["PHP_SELF"];//显示当前的页面名称
include '../share/DaoHang.php';
page($total_records,$page_size,$page_current,$url);
?>
</body>
</html>