<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<style type="text/css">
body { 
	background:#f0e6dc;
}
#content{
	width:390px;
	height:270px;
	margin:auto;
	border:#F99 solid 2px;
	background-color:#f6c5b4;
	}
#top{
	width:390px;
	height:30px;
	line-height:30px;
	text-align:center;
	font-size:24px;
	background-color:#F36;
	color:#333;
	}
#left{
	width:130px;
	height:220px;
	float:left;
	background-color:#0F9;
	}
#right{
	width:260px;
	height:220px;
	float:right;
	}

/*这是第二个表格样式*/	
table{
	background-color:#C66;
	margin:auto;
	border-collapse:collapse;/*让表格的间隙消失*/
			/*caption-side:bottom;这是设置标题的位置*/
}
tr:hover{
	background-color:#FFF;
	color:#00F;
}
tr{
	background-color:#f6c5b4;
	font-size:14px;
}
td{
	color:#74534a;
	border:#931966 solid 1px;
}
.th{
	background-color:#f0a36d;
	font-size:14px;
	color:#333;
	border:#931966 solid 1px;
}
.p{
	position:relative;
	}
</style>
</head>

<body>
<div id="content">
<div id="top">课程细节</div>
<div id="left">
<img src="../uploadpics/
<?php 
if(isset($_GET["couNo"])) 
{
	$couNo=$_GET["couNo"];
}
echo $couNo?>.jpg"  width="130" height="220" />
</div>

<?php
session_start();
$username=$_SESSION['user_name'];
if(isset($_GET["couNo"])) 
{
	$couNo=$_GET["couNo"];
}
/*问老师，变量传递过来是005,002等等的，但是输出的是5,2，会把前面的零去掉，为什么？？*/
echo "<div id='right'>";
include '..\share\GongYong.php';
$conn = get_Connect();
$sql = "select CouNo,CouName,kind,Credit,Teacher,SchoolTime,department.DepartName,LimitNum from course,department where course.DepartNo=department.DepartNo and course.CouNo=$couNo";
$result = mysql_query($sql);
echo "<table width='260' height='220' cellspacing='3' cellpadding='5' class='table'>";
$str="";
while($res=mysql_fetch_array($result)){
			$str.="<tr>
                            <td class='th'>课程编号</td>
                            <td>$res[CouNo]</td>
                        </tr>
                        <tr>
                            <td class='th'>课程名称</td>
                            <td>$res[CouName]</td>
                        </tr>
                        <tr>
                            <td class='th'>类型</td>
                            <td>$res[kind]</td>
                        </tr>
                        <tr>
                            <td class='th'>学分</td>
                            <td>$res[Credit]</td>
                        </tr>
                        <tr>
                            <td class='th'>教师</td>
                            <td>$res[Teacher]</td>
                        </tr>
                        <tr>
                            <td class='th'>上课时间</td>
                            <td>$res[SchoolTime]</td>
                        </tr>
						<tr>
                            <td class='th'>开发系部</td>
                            <td>$res[DepartName]</td>
                        </tr>
                        <tr>
                            <td class='th'>限定人数</td>
                            <td>$res[LimitNum]</td>
                        </tr>";
		}
echo $str;
echo "</table>";
echo "</div>";
echo "<form action='..\student\StuCour.php' method='post'style='margin-top: 260px;'><input type='submit' value='返回'  style='float:right;margin-right: 100px;'/></form>";
$sql2 = "select State from stucou where CouNo=$couNo and StuNo='$username'";
$result2 = mysql_query($sql2);
$res2=mysql_fetch_array($result2);
if($res2['State']=='报名'){
echo "<form method='post' style='margin-top: 260px;text-align: center;'><input type='submit' value='取消报名' name='xq' class='p'/></form>";
if(isset($_POST["xq"])){
$sql8="delete from stucou where StuNo='$username' and CouNo='$couNo'";
	$result8 = mysql_query($sql8);
	echo '<script language="JavaScript">alert("取消报名成功！");location.href="myCour.php"</script>;';	
}
}else{
echo "<form method='post'><input type='submit' value='选择报名' name='xz' class='p'/></form>";
if(isset($_POST["xz"])){
/*$sql3 = "select* from stucou where CouNo=$couNo and State='报名'";
$result3 = mysql_query($sql3);
$total_records3=mysql_num_rows($result3);
$res3=mysql_fetch_array($result);
if($total_records3<$res3['LimitNum']){*/
$sql4 = "select* from course where CouNo=any(select CouNo from stucou where StuNo='$username')";
$result4 = mysql_query($sql4);
@$total_records4=mysql_num_rows($result4);
if($total_records4>=5){
echo '<script language="JavaScript">alert("你的个人课程数目已经达到上限，请先删除一些课程再选择吧？");location.href="myCour.php"</script>;';	
}else{
	$a=rand(1,5);
	$sql6="insert into stucou (StuNo,CouNo,WillOrder,State) values ('$username','$couNo','$a','报名')";
	$result6 = mysql_query($sql6);
	echo '<script language="JavaScript">alert("恭喜你，报名成功！");location.href="myCour.php"</script>;';	
}
/*}else{
	echo '<script language="JavaScript">alert("该门课程报名人数已经到达上限，请选择其他课程吧");location.href="SelectCour.php"</script>;';
}*/
}
}
?>
</div>
</body>
</html>