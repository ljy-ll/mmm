<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<style type="text/css">
*{margin:0;padding:0}
body { font-size:12px; 
font-family:Verdana;
}
#id{
	text-align:center;
	}
.link{
	background: white;
    border: 1px solid #e5e5e5;
    border-radius: 2px;
    display: inline-block;
    font-size: 13px;
    height: 24px;
    line-height: 24px;
    margin-right: 5px;
    text-align: center;
    text-decoration: none;
    vertical-align: middle;
    width: 60px;
}
span a{
	background: white;
	color:#333;
    border: 1px solid #e5e5e5;
    border-radius: 2px;
    display: inline-block;
    font-size: 13px;
    height: 24px;
    line-height: 24px;
    margin-right: 5px;
    text-align: center;
    text-decoration: none;
    vertical-align: middle;
    width: 36px;
}
span a:hover{
	background-color:#e6f2fe;/*鼠标悬停的样式*/
	border:#5d9cdf solid 1px;
}
span a:link{
	color:#00C;/*未被访问前的样式*/
    text-decoration:none;
    text-align:center;
}
span a:visited {
	color:#000;
	font-family:"黑体";
}

</style>
</head>

<body>
<?php
function page($total_records,$page_size,$page_current,$url){
$total_pages=ceil($total_records/$page_size);//数据分几页
$page_prevous = ($page_current<=1)? 1:$page_current-1;//上一页如果是1，就显示1，否则是选的减一
$page_next = ($page_current>=$total_pages)? $total_pages:$page_current+1;
//下一页如果是最后一页，就显示最后一页，否则是选的加一
$navigator = "<span><a href=$url?page_current=$page_prevous class='link'>上一页</a></span>"."&nbsp;&nbsp;&nbsp;&nbsp;";//做导航条
$page_start=($page_current-2>0)?$page_current-2:0;//那个页码在中间
$page_end=($page_start+3<$total_pages)? $page_start+3:$total_pages;
//显示几个页码在页面
$page_start=$page_end-3;
for($i=$page_start;$i<$page_end;$i++){
			$j = $i+1;
			$navigator.="<span><a href='$url?page_current=$j'>$j</a></span>&nbsp;&nbsp;&nbsp;&nbsp";		
//遍历页码
}
$navigator.="<span><a href=$url?page_current=$page_next class='link'>下一页</a></span><br>";
$navigator.="<br>"."共".$total_records."条记录&nbsp;&nbsp;&nbsp;&nbsp;共".$total_pages."页&nbsp;&nbsp;&nbsp;&nbsp;当前是第".$page_current."页";
echo "<div id='id'>";
echo "<br>".$navigator;
/*echo "<table cellpadding='0' cellspacing='1' border='4'>";
echo "<tr>";
echo "<td>".$navigator."</td>";
echo "</tr>";
echo "</table>";*/
echo "<div>";
}
?>
 
</body>
</html>