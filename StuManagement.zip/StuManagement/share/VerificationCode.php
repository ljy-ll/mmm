<?php
header("Content-type:image/gif");
$border=1;//是否要边框1是true，0是false
$many=4;//多少个验证码
$width=$many*16;//验证码图片的长度
$height=22;//验证码的高度
$fontSize=5;//字体的大小
$zimu="abcdfghijklmnopqrstuvywxz";
$number="0123456789";
$VerificationCode="";//初始化验证码
$im = imagecreate($width,$height);//建立个画布
$bgColor=imagecolorallocate($im,255,255,255);//要填的充颜色
imagefill($im,0,0,$bgColor);//填充
//画边框
if($border){
	$black=imagecolorallocate($im,0,0,0);
    imagerectangle($im,0,0,$width-1,$height-1,$black);
}
//随机产生字符
for($i=0; $i<$many; $i++) 
{
	$zimu_or_number=mt_rand(0,1);//随机产生0到1的数，是整形，所以一定是1
	$str=$zimu_or_number? $zimu:$number;//1是true,所以是字母
	$which=mt_rand(0,strlen($str)-1);//随机在26个字母中选取
	$code=substr($str,$which,1);//保证截取到一个字母substr(截取什么，从哪里截取，截取个数)
	$j=!$i ? 6:$j+15;//字母离边框的距离
	$color3=imagecolorallocate($im,mt_rand(0,100),mt_rand(0,100),mt_rand(0,100));//字符随机颜色
	imagechar($im,$fontSize,$j,3,$code,$color3);//绘制字符
	$VerificationCode.=$code;//把等号后变量code的所有值以字符串的形式合并到变量VerificationCode中
}
//添加干扰线（6条）
for($i=0; $i<6;$i++) 
{//干扰线的颜色
	$color1=imagecolorallocate($im,mt_rand(0,255),mt_rand(0,255),mt_rand(0,255));
	//画狐线
	imagearc($im,mt_rand(-5,$width),mt_rand(-5,$height),mt_rand(20,300),mt_rand(20,200),55,44,$color1);
}
//添加干扰点
for($i=0; $i<$many*40;$i++) 
{
	//添加干扰点颜色
	$color2=imagecolorallocate($im,mt_rand(0,255),mt_rand(0,255),mt_rand(0,255));
	//绘制干扰点
	imagesetpixel($im,mt_rand(0,$width),mt_rand(0,$height),$color2);
}
//启动session
session_start();
$_SESSION["VCode"] = $VerificationCode;//存储验证码
imagegif($im);
imagedestroy($im);
?>