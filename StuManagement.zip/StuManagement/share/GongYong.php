<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<style type="text/css">
p{
	margin:auto;
	text-align:center;
	}
</style>
</head>

<body>
<?php
function get_Connect() {
$connection = @mysql_connect("localhost","root","") or die(print("<p>与连接服务器失败！！</p>"));
mysql_query('set names utf8');
if($connection) //echo "<p>与连接服务器成功！</p>";
$dblink = mysql_select_db("xk",$connection) or die(print("<p>无法激活xk数据库</p>"));
if($dblink){
//echo "<p>激活xk数据库成功!</p>";
}
return $connection;
}
?>
</body>
</html>