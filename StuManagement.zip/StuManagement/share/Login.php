<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<?php
if(isset($_POST["login"])) {
$username = $_POST['UserN'];
$passW = $_POST["PassW"];
$Kinds = $_POST["kind"];
session_start();
$_SESSION["user_name"] = "$username";//PHP md5() 函数
$_SESSION["password"] = md5("$passW");
$_SESSION["登录类型"] = "$Kinds";
$code = $_POST["code"];
if($username!="" && $passW!="" && $code!=""){
include '../share/GongYong.php';
$conn = get_Connect();
if($Kinds=="学生"){
@$q = mysql_query("select StuNo,Pwd from student where StuNo='$username' and Pwd='$passW'");
}else{
	@$q = mysql_query("select TeaNo,Pwd from teacher where TeaNo='$username' and Pwd='$passW'");
}
@$numrow = mysql_num_rows($q);//查询是否已经存在用户
if($numrow && $_POST["code"]==$_SESSION["VCode"]){
	//判断已经存在
	if($Kinds=="学生"){
	header("Location:../student/StuCour.php");
	}else{
	header("Location:../teacher/Course.php");	
		}
}else{
	if($Kinds=="学生"){
	@$q1 = mysql_query("select StuNo from student where StuNo='$username'");
	}else{
	@$q1 = mysql_query("select TeaNo from teacher where TeaNo='$username'");
		}
    @$numrow1 = mysql_num_rows($q1);//查询学号是否正确
if($numrow1){ //如果学号正确
	if($_POST["code"]!=$_SESSION["VCode"]){
	 echo '<script language="JavaScript">;alert("亲,你输入的验证码不正确！");window.location = "../Login.html";</script>;';
	}else{
	echo '<script language="JavaScript">;alert("亲,你输入的密码或者登陆类型有错误,请重新填写或选择！");window.location = "../Login.html";</script>;';
	}
}else{
	 echo '<script language="JavaScript">;alert("亲,你输入的学号不存在,请重新填写！");window.location = "../Login.html";</script>;';
}
}
}else{
	echo '<script language="JavaScript">;alert("亲，请填写完整信息，再提交！");window.location = "../Login.html";</script>;';
	}
	mysql_close($conn);
}
?>
</body>
</html>