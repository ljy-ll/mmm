-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 年 11 月 26 日 02:12
-- 服务器版本: 5.5.24-log
-- PHP 版本: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `xk`
--

-- --------------------------------------------------------

--
-- 表的结构 `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `ClassNo` char(8) NOT NULL,
  `DepartNo` char(2) NOT NULL,
  `ClassName` char(20) NOT NULL,
  PRIMARY KEY (`ClassNo`),
  KEY `DepartNo` (`DepartNo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `class`
--

INSERT INTO `class` (`ClassNo`, `DepartNo`, `ClassName`) VALUES
('20000001', '01', '00鐢靛瓙鍟嗗姟'),
('20000002', '01', '00澶氬獟浣'),
('20000003', '01', '00鏁版嵁搴'),
('20000004', '02', '00寤虹瓚绠＄悊'),
('20000005', '02', '00寤虹瓚鐢垫皵'),
('20000006', '03', '00鏃呮父绠＄悊'),
('20010001', '01', '01鐢靛瓙鍟嗗姟'),
('20010002', '01', '01澶氬獟浣'),
('20010003', '01', '01鏁版嵁搴'),
('20010004', '02', '01寤虹瓚绠＄悊'),
('20010005', '02', '01寤虹瓚鐢垫皵'),
('20010006', '03', '01鏃呮父绠＄悊'),
('20020001', '01', '02鐢靛瓙鍟嗗姟'),
('20020002', '01', '02澶氬獟浣'),
('20020003', '01', '02鏁版嵁搴'),
('20020004', '02', '02寤虹瓚绠＄悊'),
('20020005', '02', '02寤虹瓚鐢垫皵'),
('20020006', '03', '02鏃呮父绠＄悊');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
