-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 年 11 月 26 日 02:12
-- 服务器版本: 5.5.24-log
-- PHP 版本: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `xk`
--

-- --------------------------------------------------------

--
-- 表的结构 `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `CouNo` char(3) NOT NULL,
  `CouName` char(30) NOT NULL,
  `Kind` char(8) NOT NULL,
  `Credit` decimal(5,0) NOT NULL,
  `Teacher` char(20) NOT NULL,
  `DepartNo` char(2) NOT NULL,
  `SchoolTime` char(10) NOT NULL,
  `LimitNum` decimal(5,0) NOT NULL,
  `WillNum` decimal(5,0) NOT NULL,
  `ChooseNum` decimal(5,0) NOT NULL,
  PRIMARY KEY (`CouNo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `course`
--

INSERT INTO `course` (`CouNo`, `CouName`, `Kind`, `Credit`, `Teacher`, `DepartNo`, `SchoolTime`, `LimitNum`, `WillNum`, `ChooseNum`) VALUES
('001', 'SQL SERVER鎶?湳涓庡簲鐢', '宸ョ▼鎶?湳', '3', '寰愪汉鍑?', '01', '鍛ㄤ簩5-6鑺', '25', '43', '0'),
('002', 'JAVA鎶?湳鐨勫紑鍙戝簲鐢', '淇℃伅鎶?湳', '2', '绋嬩紵褰', '01', '鍛ㄤ簩5-6鑺', '10', '35', '0'),
('003', '缃戠粶淇℃伅妫?储鍘熺悊涓庢妧鏈', '淇℃伅鎶?湳', '2', '鏉庢稕', '01', '鍛ㄤ簩鏅', '10', '29', '0'),
('004', 'Linux鎿嶄綔绯荤粺', '淇℃伅鎶?湳', '2', '閮戞槦', '01', '鍛ㄤ簩5-6鑺', '10', '33', '0'),
('005', 'Premiere6.0褰辫?鍒朵綔', '淇℃伅鎶?湳', '2', '鏉庨煹濠', '01', '鍛ㄤ簩5-6鑺', '20', '27', '0'),
('006', 'Director鍔ㄧ敾鐢靛奖璁捐?涓庡埗浣', '淇℃伅鎶?湳', '2', '闄堝瓙浠', '01', '鍛ㄤ簩5-6鑺', '10', '27', '0'),
('007', 'Delphi鍒濈骇绋嬪簭鍛', '淇℃伅鎶?湳', '2', '鏉庡叞', '01', '鍛ㄤ簩5-6鑺', '20', '27', '0'),
('008', 'ASP.NET搴旂敤', '淇℃伅鎶?湳', '3', '鏇惧缓鍗', '01', '鍛ㄤ簩5-6鑺', '10', '45', '0'),
('009', '姘磋祫婧愬埄鐢ㄧ?鐞嗕笌淇濇姢', '宸ョ▼鎶?湳', '2', '鍙惰壋鑼', '02', '鍛ㄤ簩鏅', '10', '31', '0'),
('010', '涓?骇鐢靛伐鐞嗚?', '宸ョ▼鎶?湳', '3', '鑼冩暚涓', '02', '鍛ㄤ簩5-6鑺', '5', '24', '0'),
('011', '涓??寤虹瓚娆ｈ祻', '浜烘枃', '2', '鏋楁硥', '02', '鍛ㄤ簩5-6鑺', '20', '27', '0'),
('012', '鏅鸿兘寤虹瓚', '宸ョ▼鎶?湳', '2', '鐜嬪?', '02', '鍛ㄤ簩5-6鑺', '10', '21', '0'),
('013', '鎴垮湴浜ф极璋', '浜烘枃', '2', '榛勫己', '02', '鍛ㄤ簩5-6鑺', '10', '36', '0'),
('014', '绉戞妧涓庢帰绱', '浜烘枃', '2', '椤捐嫅鐜', '02', '鍛ㄤ簩5-6鑺', '10', '24', '0'),
('015', '姘戜織椋庢儏鏃呮父', '绠＄悊', '2', '鏉ㄥ浗娑', '03', '鍛ㄤ簩5-6鑺', '20', '33', '0'),
('016', '鏃呰?绀剧粡钀ョ?鐞', '绠＄悊', '2', '榛勬枃鏄', '03', '鍛ㄤ簩5-6鑺', '20', '36', '0'),
('017', '涓栫晫鏃呮父', '浜烘枃', '2', '鐩涘痉鏂', '03', '鍛ㄤ簩5-6鑺', '10', '27', '0'),
('018', '涓??鑿滆偞鍒朵綔', '浜烘枃', '2', '鍗㈣悕', '03', '鍛ㄤ簩5-6鑺', '5', '66', '0'),
('019', '鐢靛瓙鍑虹増姒傝?', '宸ョ▼鎶?湳', '2', '鏉庡姏', '03', '鍛ㄤ簩5-6鑺', '10', '0', '0');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
